#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])

 {
 	
 	
   char name[12]; ///%c %s
   float weight;
   int age;
   char city[14];
   char country[15];
   
   printf("\t \t **** Welcome to Aptech Qatar ***********\n");
   
   printf("\t \t \n Please enter Your Name Sir: ");
   scanf("%s", &name);
   
   printf("\t \t \n Please enter your Weight Sir: ");
   scanf("%f", &weight);
   
   printf("\t \t \n Please enter Your age Sir: ");
   scanf("%d", &age);
   
   printf("\t \t \n Please enter your city Sir: ");
   scanf("%s", &city);   //strings
   
   printf("\t \t \n Please enter your country name Sir:");
   scanf("%s", &country);
   
   
   printf("\t \t \n your name is : %s", name);
   printf("\t \t \n your weight is : %f", weight);
   printf("\t \t \n your age is : %d", age);
   printf("\t \t \n your city is : %s", city);
   printf("\t \t \n your country is : %s", country);
   
	return 0;
}
