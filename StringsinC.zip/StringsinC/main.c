#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()

 {
 	//Strings in c 
 	
 char num_1[] ={'A', 'P', 'T', 'E', 'C','H'};
 	
    char num_2[] = "APTECH";
    
    
    printf("Ouput of Array is : %s \n ", num_1);
    printf("String literal is : %s ", num_2); 
    
    char str[20];
    
    printf("\n Enter the string: ");
    scanf("%s", &str);
    
    printf("The string is : %s", str);
    
 	
 	
 	
 	
	return 0;
}
