#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])
 {
 	//gets
 	
     
 	char name[40];
 	
 	printf("Welcome to Qatar!!!1");
 	
 	printf("\n Enter First name");

 	gets(name);  ///scanf("%s", &name);
 	
 	printf("The string is :");
 	
 	puts(name);
 	
 	
 	
 	
 	
	return 0;
}
