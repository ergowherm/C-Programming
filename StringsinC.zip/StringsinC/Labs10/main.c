#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])

 {
 	// 100, 100.67, 'f'
 	
 /*	int num = 100;   
 	float num_2 = 100.67; 
 	char Gender = 'F';  
 	
 	printf("\n %d", num);
 	printf("\n %f", num_2 );
 	printf("\n %c", Gender); */
 	
 	/*char str[8]={'a', 'p', 't', 'e', 'c', 'h'};
 	
 	//welcome to C progrraming
 	
 	char str_2[30];
 	
 	printf("\n %s", str);
 	
 	printf("\n %s", str_2); */
 	
 /*	char Name[7];
 	char Degree[20];
 	int QID[15];
 	
 	printf("\n \t \t \t  Enter the name: ");
 	scanf("%s", &Name);
 	
 	printf("\n \t \t Enter the Degree you have: ");
 	scanf("%s", &Degree);
 	
 	printf("\n \t \t Enter the QID please :");
 	scanf("%d", &QID);
 	
 
 	printf("\n \t \t The Name is : %s", Name);
 	printf("\n \t \t The Degree is : %s", Degree);
 	printf("\n \t \t The QID is : %d", QID);*/
 	
 	//strlen90


  /*  char InstituteName[50];

    
      printf("The length of the String is : %d", strlen(InstituteName)); */
    
 	
 	//strcopy()
 	
 /*	char str1[12] = "AptechQatar";
 	char str2[12];
 	
  printf("\n The  value of str2: %s", str2);
 	
 	strcpy(str2, str1);
 	
 	printf("\n The  value of str2: %s", str2);
 	printf("\n The  value of str1: %s", str1); */
 	
 	//strcat
 	
 /*	char str1[20];
 	char str2[6];
 	
 	printf("\n \t The string inside str1 is : %s", str1);
 	printf("\n \t The string inside str2 is : %s", str2);
 	
 	strcat(str1, str2);
 	
 	printf("\n \t \t The Concatenated string is : %s", str1); */
 	
 	
 /*	char str1[20];
 	char str2[20];
 	

    printf("Enter the String 1: ");
    gets(str1);
    
    printf("Enter the String 2: ");
    gets(str2);
    
    if(strcmp(str1, str2)==0)
    
	{
    	printf("\n \n \t \t Strings are equal");
    	
    	
	}
	
	else {
		
		printf("\n\n \t \t Strings are not Equal");
	}
 	 */
 	 
 	 
 /*	 char hadeel[12];
 	 
 	 printf("Enter the name please: ");
 	 gets(hadeel);
 	 
 	 //puts(hadeel);
 	 printf("The name is : %s", hadeel);
 //	 printf("\n \n \t \t The Reverse String is : %s", strrev(hadeel));
 	 
    printf("\n \n \t \t The Lower case String is : %s",strlwr(hadeel));
 	
 	printf("\n \n \t \t The Lower case String is : %s",strupr(hadeel)); */
 	
 	 // strstr()
 	 
 	 
 	 char str1[30] = "My college name is aptechqatar";
 	 char *sub;
 	 
 	 sub = strstr(str1, "name");
 	 
 	 printf("\n The substring is : %s", sub);
 	 
 	
 	
 	
 	
 	
 	
 	
 	
 	
	return 0;
}
