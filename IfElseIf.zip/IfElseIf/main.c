#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()

 {
 	
 	float Marks;
 	printf("\n \t \t \t ******* Welcome to Aptech Qatar Grading System******");
 	printf("\n \t \t \t *****A next Generation Grading System**********");
 	printf("\n Please Enter the Marks: ");
 	
 	scanf("%f", &Marks);
 	
 	if (Marks > 85 && Marks <=100)
	 
	 {
 		printf("\t \t Congratulations We have achieved Grade A");
	 }
	 
	else if( Marks > 60 && Marks <=85)
	
	{
		printf("Congo You are in Grade B+");
		
	
	}
	
	else if (Marks > 50 && Marks <= 60)
	
	{
		
		printf("Good One your Grade is C");
	}
	
	else if (Marks > 40 && Marks <= 50)
	{
		
		printf("Nice!!! Your Grade is D");
	}
	
	else if (Marks > 33 && Marks <= 40)
	{
		
		printf("Your Grade is E");
	}
	
	else if (Marks >1   && Marks <=33 )
	{
		
		printf("Your Grade is F Sorry you failed Register Again");
	}
	 
	 else 
	 
	 {
	 	
	 	printf("opps error Unknown Entry Please check it out ");
	  } 
	 
	 
 	
 	
 	
 	
 	
 	
	return 0;
}
