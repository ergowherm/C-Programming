#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 

{
	printf("\n \t \t \t *********Price Sytem of Apple Com*******************");
	printf("\n \n \t \t \t Welcome to the Newly Launched Price System ************");
	int price;
	
	printf("\n \n \t \t Would please enter your Budget: ");
	scanf("%d", &price);
	
	switch (price)
	{
		
		case 899:
			printf("\n You are lucky You can buy Apple 11 Congratulation!!!");
			printf("\n To continue: \n 1. Buy \n 2. Add to Cart \n 3. Exit");
			break;
			
		case 999:
			printf("\n Nice! You can purchase Apple 11 Pro Please go ahead");
			printf("\n To continue: \n 1. Buy \n 2. Add to Cart \n 3. Exit");
			break;
			
	    case 1200:
	    	printf("\n Wow You can purchase our industries best smartphone");
	    	printf("\n Apple 11 Pro Max");
		    printf("\n To continue: \n 1. Buy \n 2. Add to Cart \n 3. Exit");
		    break;
		default:
			printf("\n oops error! We dont have any product based on this Budget");
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
