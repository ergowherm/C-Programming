#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() 

{
    const float Pie;
    
    printf("Enter the Value of Pie: ");
    
    scanf("%f", &Pie);
    
    
    printf("The constant value is : %f", Pie);
	
		  
	
	
	
	
	return 0;
}
