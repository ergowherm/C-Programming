#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int addition();
int main(int argc, char *argv[]) 
{
	int result;
	
	int (*ptr)(); //
	
	ptr = &addition;
	
	result = (*ptr)();
	
	printf ("The value is %d", result);	
	
}

   int addition()
   {
   	  int a,b;
   	  
   	  printf("Enter number 1: ");
   	  scanf("%d",&a);
   	  
   	  printf("Enter number 2: ");
   	  scanf("%d",&b);
   	  
   	  return a + b;
   	
   }
// Pointer increment
/*	int number = 30;
	
	int *age;
	
	age = &number;
   printf("The value is  :%d", *age);
   
	printf("\n Addres of the variable number is :%d", age);
	age = age - 5;  // 4 * 5 = 20 // 4 * 5 = 20
	
	printf("\n After Increment : The address is : %d", age); */

