#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])


 {
 	 /*  int number=50;
		  
		  int age = 28;
		  
		  int *c;
		  
		  c = &age;  
       int *p; 
	        
       p=&number;
	       
        printf("Address of p variable is %x \n",p);
     
     
       printf("Value of p variable is %d \n",*p);
       printf("Address of p variable is %x \n",c);
       return 10;*/
       
       
       //double pointer:
       
       
       int age = 28;
       
       int *num_1;
       int **num_2;
       
       num_1=&age;
       num_2=&num_1;
       
       
    printf("address of num_1: %x \n",num_1); 
    printf("address of num_2: %x \n",num_2); 
    printf("value stored at num_1: %d\n",*num_1);
    printf("value stored at num_2: %d\n",**num_2);
       
       
     
	   
	}
 
 	
 	
 	

