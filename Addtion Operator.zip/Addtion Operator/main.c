#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int age = 29;
int main(int argc, char *argv[])

 {
 	  // Adding the two numbers 
 	  
 	/*  int num1, num3;
 	  float num2;
 	  
 	  
 	  printf("Enter the Num1: ");
	   scanf("%d", &num1);
	   
	  printf("Enter the Num2: ");
	  scanf("%f", &num2);
	  
	  printf("Enter the Num3: ");
	  scanf("%d", &num3);
 	  
 	  
 	  float result = num2 + num1+ num3;
 	  
 	  printf("The addition of two Numbers is: %f", result);*/
 	  
 	  
 	  // Increment and decrement Operators
 	  
 	   // ++ and --
 	   
 	   
 	  /* int num = 20;
 	    num += 5;
 	    
 	   printf("the num is :%d", num++);
 	   
 	   printf("\n The number after incremnt operator is: %d", num--);
 	   
 	   printf("\n The number after decrement operator is: %d", num); */
 	   
 	   
 	   int BMW = 40;
 	   int Ferrari = 50;
 	   
 	   if ( BMW > Ferrari)
 	   {
 	   	
 	   	printf("BMW is having more Milege");
 	   	
		}
		
 	  else 
	   {
 	  	
 	  	printf("Ferrari is having more Milege");
 	  	
 	  	
	   }
 	  
 	  
 	  
 	  
 	  
 	  
 	  
 	  
 	
 	
	return 0;
}


   mimoun()
   {
   	  int a = 10;
   	
   	
   }
