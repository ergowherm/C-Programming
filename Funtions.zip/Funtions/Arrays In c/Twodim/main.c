#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 


{
	//Example of two dimen
	
/*	int i, j;
	
	int arr[4][3]={{1,2,3}, {4,5,6}, {7,8,9}, {10, 11, 12}};
	
	for (i= 0; i <= 3; i ++){
		
		
		for (j = 0; j <= 2; j++){
			
			
			printf("arr [%d] [%d] = %d \n ", i, j, arr[i][j]);
		}
	} */
	
	
	int arr[3][3], i, j;
	
	for(i= 0 ; i <= 2 ; i++) {
		
		for (j=0 ; j <= 2 ; j ++)
		{
			
			printf("Enter the Values at [%d] [%d] :", i, j);
			scanf("%d", &arr[i][j]);
			
		}
	
	}
	
	
	printf("\n *************** print the elements............ \n");
	
	for (i = 0; i <= 2; i++)
	{
		printf("\n ");
		for (j = 0 ; j <= 2 ; j++){
			
			
			printf("%d \t", arr[i][j]);
		}
	}
	
	
	
	return 0;
}


