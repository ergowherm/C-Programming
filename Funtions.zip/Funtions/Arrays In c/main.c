#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])


 {
 	
 	int i;
 	
 	int Marks[6] = {10, 16, 18, 90, 98, 98}; //Decalaration of an Array
 	
 	
 	for (i = 0 ; i <= 5 ; i++)
	 
	 {
 		printf("%d\n", Marks[i]);
 		
	 }
 	
	return 0;
}
