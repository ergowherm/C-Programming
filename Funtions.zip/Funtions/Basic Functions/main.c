#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


//Declaration
int Addition();
int subtraction(int, int);

int main(int argc, char *argv[])

 {
 	printf("\n \n \t \t \t *****Welcome to TechWood********");
 	
 	int num_1, num_2;
 	printf("\n Enter the two values: ");
 	scanf("%d %d", &num_1, &num_2);
 	
 	subtraction(num_1, num_2);
 	
 	
   // Calling a function
    Addition();
 	
 	
	return 0;
}

int subtraction(int num_1, int num_2)
 {
 	
 	printf("\n \t The profit  is = %d ", num_1 - num_2);
 }

/*int Aptech()  //Definition

{
	
	printf("Welcome to Aptech \n How can we help you!:");
	printf("\n Student: My name is Miss. Lubna ");
	printf("\n Student: I want to enroll in ACCP ");
	
} */

int Addition( )

{
	  int Apple_8;
	  float Apple_11, Total_Price;
	  
	  printf("\n \n  \t \t  Enter the Price of Apple 8: ");
	  scanf("%d", &Apple_8);
	  printf("\n \t \t  Enter the Price of Apple 11: ");
	  scanf("%f", &Apple_11);
	  
	  Total_Price = Apple_8 + Apple_11;
	  
	  printf("\n \t \t You need to pay : %f", Total_Price);
	  
	  

	
	
}

 

	



