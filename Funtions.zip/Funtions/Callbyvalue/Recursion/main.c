#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int fac(int);
int main(int argc, char *argv[]) 

{
	int n, result;
	
	printf("Enter the Number: ");
	scanf("%d", &n);
	
	result = fac(n);
	printf("Factorial = %d", result);
	
	
	
	return 0;
}

int fac(int n)
{
	if  (n == 0)
	{
		
		return 0;
	}
	else if (n == 1)
	{
		
		return 1;
	}
	else 
	{
		return n * fac (n - 1);
		
	}
	
	
	
}













