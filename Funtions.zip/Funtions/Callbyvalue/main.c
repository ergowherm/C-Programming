#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int change (int *num)
{
	
	printf("Before adding value inside function num = %d \n", *num);
	*num = *num + 100;
	printf("After adding value inside function num= %d \n ", *num);
	
}

int main(int argc, char *argv[])

 {
 	
 	int a= 100;
 	
 	printf("Value before the funtion call a = %d\n", a);
 	
 	change(&a); //call by reference
 	printf("Value after calling the function a= %d\n", a);
 	
 	
	return 0;
}
     

