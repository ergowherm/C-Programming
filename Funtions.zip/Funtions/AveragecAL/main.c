#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int avg(int, int, int);
int main(int argc, char *argv[]) 

{
	
	avg(a,b,c);
	
	return 0;
}

int avg (int a, int b, int c)
{
	
	int a=10, b = 20, c =30;
	float average= a + b + c /3;
	printf("The Average is %f", average);
	
}
