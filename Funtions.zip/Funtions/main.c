#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int display();  // Declaring

int lobna();

int main()

 {
 	
 	display();  // Function call
    lobna();
 	
}

int display()
{
	//Defining a funtion
	
	printf("\n \t \t Hello This is the first Funtion used in C");
	printf("\n \t \t We will be now learning Funcions in C Prog. ");
	

}

int lobna()

{
	printf("\n \t Lobna is from Sudan! \n \t  She is currently a student \n");
	printf("\t of Aptech Qatar Registered in ACCP Course");
	
}



