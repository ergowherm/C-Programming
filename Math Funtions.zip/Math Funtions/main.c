#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 

{
	
   	printf("\n \t \t **********Math Funtions Tutorial*****************");
   	
   	//Ceil Funtion
   	printf("\n \t \t  The Ceil value is: %f", ceil(3.6));
    printf("\n \t \t The Ceil value is: %f", ceil(3.2));
	
	//floor funtions
	printf("\n \t \t The Floor value is: %f", floor(3.6));
    printf("\n \t \t The Floor value is: %f", floor(3.2));

    
    //sqrt function
   printf("\n \t \t The Square root of 81 is: %f", sqrt(81));
   printf("\n \t \t The Square rooot of 16 is: %f", sqrt(16));
   
   //pow(2 power 10) 
   
   printf("\n \t \t The value after calculation: %f", pow(2, 10));   
    
    //asb(-100)
    
    printf("\n \t \t The absulte value is: %d", abs(-12));
    
    
	
	
	
	
	return 0;
}
