#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 

{
  /*	int num = 10;  
	
	while (num <= 30)
	{
		
		printf("%d \n ", num);
		num++;  
		
	} */
	
	int i = 1, number = 0;
	
	printf("Enter the Number :");
	scanf("%d", &number);
	
	while (i <= 16)
	{
	
	   	printf("\n \t \t %d * %d = %d",number, i, (number * i));
	   	i++;
		  
	}

	
	

	
	
	
	
	return 0;
}
