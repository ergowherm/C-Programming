#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])

 {
 	
   /*  int num = 1;
	 
	 do {
	 	
	 	printf(" This is: %d\n", num);
	 	num = num + 1;
	 	
	 }	while (num <= 50);*/
	 
	  printf("\n \n \t \t \t \t *************Welcome to Aptech Qatar!! **************");
	  printf("\n \n \t \t \t Please choose a course and You will get the price of the course");
	  int choice;
	  char c;
	  
	  do{
	  printf("\n \t \t List of Courses:");
	  printf("\n \t 1. ACCP \n \t 2. STC \n \t 3. English \n \n  \t choose :   ");
	  scanf("%d", &choice);
	  
	  switch (choice){
	  	
	  	case 1:
	  		printf("\n Course Price is 16000 QAR PER ANNUM");
	  		printf ("\n Course Duration is 3 Years");
	  		printf ("\n Fields to study");
	  		printf("\n 1. CISE \n 2. ACISE \n 3. Networking");
	  		break;
	  	case 2:
	  		printf("\nAptech is having more than 300 Hundred ST courses");
	  		printf("\n please choose from the most demanding ones ");
	  		printf("\n 1. Web Desiging -  \n 2. CCNA \n 3. MS OFFICE 2016 \n 4. Python");
	  		
	  		printf("Course fee for each course is 100QAR Per hour");
	  		break;
	  		
	  	case 3:
	  		printf("\n \t We have several english courses");
	  		printf ("\n 1. Begginers \n 2. Advanced \n 3. Expert ");
	  		printf("Course fee for each course is 100QAR Per hour");
	  		break;
	  		
	   default:
	   	printf("opps error!!");
	  	
	  	
	  }
	  
	  printf("\n \t \t Do you want to go back:");
	  scanf("%s", &c);
	  
}while (c == 'y');
 	
 	
 	
	return 0;
}
