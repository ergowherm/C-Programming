#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()

 {
 	
 /*	int num;
 	
 	for (num = 1; num <= 50; num++)
 	
 	{
 		printf("\n \t %d", num);
 		
 		
	 }*/
	 
/*	int n, i;
    printf("Enter an integer: ");
    scanf("%d",&n);
    
    for(i=1; i<=10; ++i)
    {
        printf("%d * %d = %d \n", n, i, n*i);
    } */
    
  /* int num;
   
   for  (num =1 ; num<= 10; ++ num)
   {
   	if  (num == 5)
   	{
   		continue;
	   }
   	printf("\n \t %d", num);
   	
   }  */
   
 	
	return 0;
}
