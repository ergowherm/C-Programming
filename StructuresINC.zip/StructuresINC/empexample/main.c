#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

struct empdatabase{
	
	//members 
	char empName[30];
    int  empId;
    int  empsalary;
    int  empphone;
    char empaddress[100];
}emp1, emp2; // variable declaration

int main(int argc, char *argv[])

 {
 	printf("\n \t \t \t *****Welcome to our employee database portal***");
 	//First employee storage
 	
 	strcpy(emp1.empName, "Mimoun Touil");
 	emp1.empId= 5675676788;
 	emp1.empsalary = 12000;
 	emp1.empphone= 76876878;
 	strcpy(emp1.empaddress, "Building no 39, Al Duhail Doha Qatar");
 	
 	
 	//Second employee storage 
 	strcpy(emp2.empName, "Carlos");
 	emp2.empId= 65766777;
 	emp2.empsalary = 11000;
 	emp2.empphone= 7566776882;
 	strcpy(emp2.empaddress, "Building no 40, Al Duhail Doha Qatar");
 	 
 	//Third one
 	
 	
 	printf("\n \n  \t \t **************Thanks for Your Details********* ");
 	printf("\n \n \t \t **************Your Details are given Below****");
 	
 	
 	//output
 	printf("\n First Employee Detials");
 	
 	printf("\n The Empname is: %s", emp1.empName);
 	printf("\n The EmpID is: %d", emp1.empId);
 	printf("\n The EmpSal is: %d", emp1.empsalary);
 	printf("\n The EmpAddress is: %s", emp1.empaddress);
 	printf("\n The EmpPhoneno is: %d\n ", emp1.empphone);
 	
 	printf("\n Second Employee Detials");
 	printf("\n  \t \t The Empname is: %s", emp2.empName);
 	printf("\n \t \t The EmpID is: %d", emp2.empId);
 	printf("\n  \t \t The EmpSal is: %d", emp2.empsalary);
 	printf("\n \t \t The EmpAddress is: %s", emp2.empaddress);
 	printf("\n  \t \t The EmpPhoneno is: %d", emp2.empphone);
	return 0;
}
