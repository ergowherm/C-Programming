#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

   struct student
   
   {
   	
   	   char name[20];
   	   int StdID;
   	   float Marks;
   	  	
   };

int main(int argc, char *argv[])

 {
 	struct student s1, s2, s3;
 
 	
 	// Allow the users to enter input the infor
 	
 	printf("Enter the Name, StdID, Marks: ");
 	scanf("%s %d %f", s1.name, &s1.StdID, &s1.Marks);
 	
 	
 	printf("Enter the Name, StdID, Marks: ");
 	scanf("%s %d %f", s2.name, &s2.StdID, &s2.Marks);
 	
 	printf("Enter the Name, StdID, Marks: ");
 	scanf("%s %d %f", s3.name, &s3.StdID, &s3.Marks);
 	
 	
 	
 	// display output 
	printf("\n ****Thank you we are printing the details.......***");
	printf("\n \t %s %d %f", s1.name, s1.StdID, s1.Marks);
	printf("\n \t %s %d %f", s2.name, s2.StdID, s2.Marks);
	printf("\n \t %s %d %f", s3.name, s3.StdID, s3.Marks);
 	
	return 0;
}
