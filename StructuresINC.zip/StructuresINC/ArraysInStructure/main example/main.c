#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

   struct student
   {
   	
   	char Name[20];
   	int  RollNo;
   	char course[20];	
   };


int main(int argc, char *argv[])

 {
 	
 	//arrays in structure 
 	struct student std[3];
 	int i;
 	//Starting
 	
 	printf("\n \t **** Welcome to the web******");
 	printf("\n Kindly enter the student Details: ");
 	
 	for(i= 0; i <= 4 ; i++)
	 
	 {
 		printf("\n Enter Name: ");
 		scanf("%s", &std[i].Name);
 		
 		printf("\n Enter the Roll No: ");
 		scanf("%d", &std[i].RollNo);
 		
 		printf("\n Enter the Course: ");
 		scanf("%s", &std[i].course);
 		
 		
	 }
	 
	 printf("Printing the details....");
	 
	 for(i= 0; i <= 4 ; i++ )
	 {
	 	
	 	printf("\n \t \t  RollNo: %d \t Name:%s \t Course: %s", std[i].RollNo,std[i].Name, std[i].course);
	 }
	 
 	
 	
 	
	return 0;
}
