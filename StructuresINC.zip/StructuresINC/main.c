#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

struct StudentDetails
{
	//Members	
	int StdID;
	char StdName[30];	
	
}e1; /// varibales

int main(int argc, char *argv[])

 {
 	e1.StdID = 1546667;
 	
 	strcpy(e1.StdName, "Mimoun Touil");

 	
 	printf("The stdid is : %d\n ", e1.StdID);

    printf("\n The stdName is : %s ", e1.StdName); 	
 	

 	
	return 0;
}
