#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])
 {
 	
 	int *str;
 	
 	str = (char *) malloc(15); //malloc
 	
 	str = "AptechQatar";
 	
 	printf("The str is : %s ", str);
 	
 	
	return 0;
}
