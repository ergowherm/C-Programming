#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 


{
	
	/* int StdID;
	 float StdMarks;
	 char StdGrade;
	 
	 printf("Please Enter the StudentId:");
	 scanf("%d", &StdID);
	 
	 printf("Enter the StudentMarks:");
	 scanf("%f", &StdMarks);
	 
	 printf("Enter the student Grade: ");
	 scanf("%s", &StdGrade);

	 
	 printf("\n The student ID is : %d", StdID);
	 printf("\n The Student Marks are : %f", StdMarks);
	 printf("\n The Grade of the student is : %c", StdGrade); */
	 
	 int num;
	 
	 printf("Enter the Number:");
	 scanf("%d", &num);
	 int result = num * 25 ;
	 printf("The cube of a number is : %d", result);
	 
	 

	return 0;
}
