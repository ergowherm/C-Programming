#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])

 {
 	
 	   printf("*******Example of Data Types and Variables********\n");
 	   
 	   printf("\n Roll is 2734");
 	
 	    int RollNo = 2734;
 	    
 	    float weight = 84.5;
 	    
 	    char Gender = 'M';
 	    
 	    

 	    printf("\n The Roll No of Miss Lubna is: %d", RollNo);
 	    
 	    printf ("\n Student weight is: %f  ", weight);
 	    
 	    printf("\n Gender is : %c", Gender );
 	    
 	    
 	    
 	
 	
	return 0;
}
