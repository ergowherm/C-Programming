#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() 
{
	int Age;
	
	printf("\t \t \t \t *******Welcome to Hamad FootBall Stadium*********");
	
	printf("\n \t \t  Please Enter the Age: ");
	scanf("%d", &Age);
	
	if (Age >= 18)
{
     
	printf("\n \t \t \t You are Allowed to Enter Please move ahead");
	printf("\n  \t \t \t    *********Thanks for coming****\n \n ");
	}
	
	else 
	{
		printf("\n \t \t  Oops sorry you are not allowed:");
		printf("\n \t \t Thanks for visiting us");
		printf("\n \t  \t We deeply regret the inconvenance");
		
		}	


	
	
	
	
	 
	
	
	return 0;
}
